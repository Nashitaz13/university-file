#if (!XNA)

namespace FarseerGames.FarseerPhysics.Mathematics
{
    public struct Vector3
    {
        public float X;
        public float Y;
        public float Z;
    }
}

#endif