﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using FarseerGames.FarseerPhysics.Dynamics;
using FarseerGames.FarseerPhysics.Mathematics;

namespace Demo4
{
    public partial class PhysicsBox : UserControl, IUpdateable
    {
        float X;
        float Y;
        float rotation;
       
        public PhysicsBox(float width, float height, float mass)
        {
            InitializeComponent();
            
            Body = CreateRectangleBody(width, height, mass);

            this.Size = new Vector2(width, height);
        }

        public void Update()
        {
            if (Body == null) return;
            if (X != Body.Position.X)
            {
              X = Body.Position.X;
              this.SetValue(Canvas.LeftProperty, Convert.ToDouble(X));
            }
            if (Y != Body.Position.Y)
            {
              Y = Body.Position.Y;
              this.SetValue(Canvas.TopProperty, Convert.ToDouble(Y));
            }
            if (Body.Rotation != rotation)
            {
              rotation = Body.Rotation;
              rotateTransform.Angle = (rotation * 360) / (2 * Math.PI);
            }
        }

        private Body CreateRectangleBody(float width, float height, float mass)
        {
            Body body = new Body();
            body.Mass = mass;
            body.MomentOfInertia = mass * (width * width + height * height) / 12;
            return body;
        }


        public Vector2 Size
        {
            set
            {
                this.Width = value.X;
                rectangle.Width = this.Width;
                translateTransform.X = -this.Width / 2;
                this.Height = value.Y;
                rectangle.Height = this.Height;
                translateTransform.Y = -this.Height / 2;
                rotateTransform.CenterX = this.Width / 2;
                rotateTransform.CenterY = this.Height / 2;
            }
            get
            {
                return new Vector2((float)this.Width, (float)this.Height);
            }
        }

        public Body Body { get; set; }


        
    }
}
