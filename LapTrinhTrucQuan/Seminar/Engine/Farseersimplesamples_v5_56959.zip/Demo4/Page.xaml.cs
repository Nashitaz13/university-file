﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using FarseerGames.FarseerPhysics;
using FarseerGames.FarseerPhysics.Mathematics;
using FarseerGames.FarseerPhysics.Dynamics;
using FarseerGames.FarseerPhysics.Collisions;
using FarseerGames.FarseerPhysics.Dynamics.Springs;
using FarseerGames.FarseerPhysics.Factories;

namespace Demo4
{
  public partial class Page : UserControl
  {
    private Storyboard gameLoop;
    private PhysicsSimulator physicsSimulator;

    //The entity you can control via the keyboard
    private PhysicsBox playerBox;

    //This list holds all the "elements" in the game, that should be updated at the gameloop tick.
    //NOTE: In this demo we have a list of the interface IUpdateable. The reason for this, is that
    //the list not only holds object of one type (PhysicsBox) anymore. Now it can also hold 
    //instances of a FixedLinearSpringBrush.
    //To make this work we extract the method that they both have, which is Update() and put it in an interface.
    //Both classes (PhysicsBox and FixedLinearSpringBrush) now implements this interface.
    private List<IUpdateable> entityList = new List<IUpdateable>();

    //Fields used to drag the PhysicsBox with the mouse
    private FixedLinearSpring mousePickSpring;
    private Geom pickedGeom;
    private FixedLinearSpringBrush mouseSpringBrush;

    public Page()
    {
      //Default Component Initializer created by VS2008, just leave it :)
      InitializeComponent();

      this.Loaded += new RoutedEventHandler(Page_Loaded);

      this.MouseLeftButtonDown += new MouseButtonEventHandler(Page_MouseLeftButtonDown);
      this.MouseLeftButtonUp += new MouseButtonEventHandler(Page_MouseLeftButtonUp);
      this.MouseMove += new MouseEventHandler(Page_MouseMove);
    }

    protected void Page_Loaded(object sender, RoutedEventArgs e)
    {
      //Setup GameLoop
      gameLoop = new Storyboard();
      gameLoop.Completed += new EventHandler(gameLoop_Completed);
      gameLoop.Duration = TimeSpan.FromMilliseconds(15); //The game will be updated every 15 millisecond
      this.Resources.Add("gameloop", gameLoop);

      //Setup PhysicsSimulator - No gravity applied this time
      physicsSimulator = new PhysicsSimulator(new Vector2(0, 0));


      //Add our PhysicsBox (PhysicsElement, Sprite, what ever you wanna call it)
      playerBox = new PhysicsBox(100, 100, 100);
      playerBox.Body.Position = new Vector2((float)this.Width / 2, (float)this.Height / 2);

      //Setup physical appearance for the playerBox. This will set the box physical boundaries for the 
      //playerBox so the PhysicsSimulator knows how the box should behave.
      Vertices playerVertices = Vertices.CreateRectangle((float)playerBox.Width, (float)playerBox.Height);
      Geom playerGeometry = new Geom(playerBox.Body, playerVertices, Vector2.Zero, 0, 12.8f); //12.8f taken from Demo2 in Farseer. Need a fix here as I dunno what it's doing :)
      

      //Setup a dummy box to test against
      PhysicsBox dummyBox = new PhysicsBox(150, 150, 2000);
      dummyBox.Body.Position = new Vector2((float)playerBox.Body.Position.X, ((float)playerBox.Body.Position.Y - (float)dummyBox.Height));
      Vertices dummyVertices = Vertices.CreateRectangle((float)dummyBox.Width, (float)dummyBox.Height);
      Geom dummyGeometry = new Geom(dummyBox.Body, dummyVertices, Vector2.Zero, 0, 12.8f); //12.8 taken from Demo2 in Farseer. Need a fix here.


      //Add the Body of the boxes here, so it will be affected by the physicsSimulator.
      physicsSimulator.Add(playerBox.Body);
      physicsSimulator.Add(dummyBox.Body);

      //Adds the geometry for the boxes to the simulator too
      physicsSimulator.Add(playerGeometry);
      physicsSimulator.Add(dummyGeometry);
      
      //Add the actual PhysicsBox(UserControl) object to the list of UserControls to be updated in the gameloop event
      entityList.Add(playerBox);
      entityList.Add(dummyBox);

      //Finally we add the PhysicsBox (UserControl) to the actual canvas where we want it to be rendered, so we can actually see it :)
      //We also add the dummyBox, else we will never see it on the canvas
      this.DrawingCanvas.Children.Add(playerBox);
      this.DrawingCanvas.Children.Add(dummyBox);

      //This will start the actual gameloop - this is where your application actually starts (from the users point of view)
      gameLoop.Begin();
    }

    protected void gameLoop_Completed(object sender, EventArgs e)
    {
      //Update the physics
      physicsSimulator.Update(.01f);

      //Update every entity in the game
      foreach (IUpdateable box in entityList)
      {
        box.Update();
      }

      gameLoop.Begin();
    }


    #region Mouse Events

    protected void Page_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      if (mousePickSpring != null && mousePickSpring.IsDisposed == false)
      {
        mousePickSpring.Dispose();
        mousePickSpring = null;
        RemoveFixedLinearSpringBrush(mouseSpringBrush);
      }
    }

    protected void Page_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      Vector2 point = new Vector2((float)(e.GetPosition(this).X), (float)(e.GetPosition(this).Y));
      pickedGeom = physicsSimulator.Collide(point);
      if (pickedGeom != null)
      {
        mousePickSpring = ControllerFactory.Instance.CreateFixedLinearSpring(physicsSimulator, pickedGeom.Body, pickedGeom.Body.GetLocalPosition(point), point, 250, 10);
        mouseSpringBrush = AddFixedLinearSpringBrushToCanvas(mousePickSpring);
      }
    }

    protected void Page_MouseMove(object sender, MouseEventArgs e)
    {
      if (mousePickSpring != null)
      {
        Vector2 point = new Vector2((float)(e.GetPosition(this).X), (float)(e.GetPosition(this).Y));
        mousePickSpring.WorldAttachPoint = point;
      }
    } 

    #endregion

    #region Private helper methods for the FixedLinearSpringBrush
    
    private FixedLinearSpringBrush AddFixedLinearSpringBrushToCanvas(FixedLinearSpring spring)
    {
      FixedLinearSpringBrush fls = new FixedLinearSpringBrush();
      fls.FixedLinearSpring = spring;
      this.LayoutRoot.Children.Add(fls);
      entityList.Add(fls);
      return fls;
    }

    private void RemoveFixedLinearSpringBrush(FixedLinearSpringBrush fls)
    {
      this.LayoutRoot.Children.Remove(fls);
      entityList.Remove(fls);
    }

    #endregion

  }
}
